# 物流凭证查询系统 - 部署文档

## 📦 项目结构

```
尾程物流凭证/
├── app.py                      # Flask 应用主文件
├── config.py                   # 配置文件
├── wsgi.py                     # WSGI 入口文件
├── gunicorn_config.py          # Gunicorn 配置
├── requirements.txt            # Python 依赖
├── start.sh                    # Linux/Mac 启动脚本
├── start.bat                   # Windows 启动脚本
├── .env.example               # 环境变量示例
├── .gitignore                 # Git 忽略文件
├── templates/                  # HTML 模板目录
│   ├── index.html             # 首页
│   └── api_docs.html          # API 文档页
└── logs/                       # 日志目录 (自动创建)
```

## 🚀 快速部署

### 1. 环境要求

- Python 3.8+
- MySQL 5.7+
- 内存: 512MB+
- 磁盘: 100MB+

### 2. 安装依赖

```bash
# 创建虚拟环境 (推荐)
python -m venv venv

# 激活虚拟环境
# Linux/Mac:
source venv/bin/activate
# Windows:
venv\Scripts\activate

# 安装依赖
pip install -r requirements.txt
```

### 3. 配置环境变量

```bash
# 复制环境变量示例文件
cp .env.example .env

# 编辑 .env 文件,修改数据库配置
# vim .env  或  notepad .env
```

**必须修改的配置项**:
- `SECRET_KEY`: 修改为随机字符串
- `DB_HOST`: 数据库主机地址
- `DB_USER`: 数据库用户名
- `DB_PASSWORD`: 数据库密码
- `DB_NAME`: 数据库名称

### 4. 初始化数据库

```bash
# 运行建表脚本
python create_logistics_table.py
```

### 5. 启动服务

**方式一: 使用启动脚本 (推荐)**

```bash
# Linux/Mac
chmod +x start.sh
./start.sh

# Windows
start.bat
```

**方式二: 直接使用 Gunicorn**

```bash
# 创建日志目录
mkdir -p logs

# 启动服务
gunicorn -c gunicorn_config.py wsgi:app
```

**方式三: 开发模式**

```bash
python app.py
```

### 6. 验证部署

访问以下地址验证服务是否正常:

- 首页: http://your-server:5000/
- API文档: http://your-server:5000/api-docs
- API测试: http://your-server:5000/api/tracking/测试物流单号

## 🔧 生产环境配置

### Nginx 反向代理配置

```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    location /static {
        alias /path/to/project/static;
        expires 30d;
    }
}
```

### Systemd 服务配置 (Linux)

创建服务文件: `/etc/systemd/system/logistics-voucher.service`

```ini
[Unit]
Description=Logistics Voucher Query System
After=network.target

[Service]
Type=notify
User=www-data
Group=www-data
WorkingDirectory=/path/to/project
Environment="PATH=/path/to/project/venv/bin"
ExecStart=/path/to/project/venv/bin/gunicorn -c gunicorn_config.py wsgi:app
ExecReload=/bin/kill -s HUP $MAINPID
KillMode=mixed
TimeoutStopSec=5
PrivateTmp=true

[Install]
WantedBy=multi-user.target
```

启动服务:
```bash
sudo systemctl daemon-reload
sudo systemctl start logistics-voucher
sudo systemctl enable logistics-voucher
sudo systemctl status logistics-voucher
```

### Docker 部署 (可选)

创建 `Dockerfile`:

```dockerfile
FROM python:3.9-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

RUN mkdir -p logs

EXPOSE 5000

CMD ["gunicorn", "-c", "gunicorn_config.py", "wsgi:app"]
```

构建和运行:
```bash
docker build -t logistics-voucher .
docker run -d -p 5000:5000 --name logistics-voucher logistics-voucher
```

## 📊 性能优化

### Gunicorn 工作进程数调整

根据服务器配置调整 `gunicorn_config.py` 中的参数:

```python
# CPU密集型应用
workers = CPU核心数 * 2 + 1

# IO密集型应用
workers = CPU核心数 * 4
```

### 数据库连接池

生产环境建议使用数据库连接池 (如 SQLAlchemy)

### 静态文件CDN

将图片等静态资源上传到CDN,减轻服务器压力

## 🔒 安全建议

1. **修改默认密钥**: 务必修改 `SECRET_KEY`
2. **使用HTTPS**: 配置SSL证书
3. **限制访问**: 使用防火墙限制数据库访问
4. **定期备份**: 定期备份数据库
5. **日志监控**: 监控访问日志和错误日志
6. **API限流**: 使用 Flask-Limiter 限制API请求频率

## 📝 日志管理

日志文件位置:
- 访问日志: `logs/access.log`
- 错误日志: `logs/error.log`
- PID文件: `logs/gunicorn.pid`

查看实时日志:
```bash
tail -f logs/access.log
tail -f logs/error.log
```

## 🔄 更新部署

```bash
# 拉取最新代码
git pull

# 安装新依赖
pip install -r requirements.txt

# 重启服务
# Systemd:
sudo systemctl restart logistics-voucher

# 或手动重启:
pkill -HUP gunicorn
```

## ⚠️ 故障排查

### 服务无法启动

1. 检查端口是否被占用: `netstat -tulpn | grep 5000`
2. 检查日志: `tail -f logs/error.log`
3. 检查数据库连接: 确认数据库配置正确

### 数据库连接失败

1. 检查数据库服务是否运行
2. 检查防火墙设置
3. 验证用户名密码
4. 确认数据库允许远程连接

### API返回500错误

1. 查看错误日志: `logs/error.log`
2. 检查数据库表是否存在
3. 验证数据格式是否正确

## 📞 技术支持

如遇问题,请查看:
- API文档: http://your-server:5000/api-docs
- 错误日志: logs/error.log

## 📄 版本信息

- 版本: 1.0.0
- 更新日期: 2025-12-30
